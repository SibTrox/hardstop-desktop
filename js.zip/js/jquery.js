$(function(){
   
    $(".icon-menu").click(function(){

        $('.div-nav').slideToggle(700);

    });



   
    $("#usuario").click(function(){

        $("#login").slideToggle(700);

    });
    $(".icon-list2").click(function(){

        $(".lista").slideToggle(700);
    
    });    


})();
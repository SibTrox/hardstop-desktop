"use strict";
(function() {
    var $boton_usuario = document.getElementById('usuario');

    /*var login = document.getElementById("login");
    var header = document.getElementById("header");
    $boton_usuario.onclick = function(event) {
        event.preventDefault();
        
        login.className = login.className.replace(/\bocultar\b/g, "");
    }
    function loginHarstop() {

    }


*/
})();
